<?php

namespace Blocktrail\SDK\Exceptions;

class NotImplementedException extends BlocktrailSDKException {

}
