</main>
<script type="text/javascript" src="js/convert-currency.js?ver=<?php echo time(); ?>"></script>
<script type="text/javascript" src="js/faq-accordian.js"></script>
<script type="text/javascript" src="js/app_js.js?ver=<?php echo time(); ?>"></script>
<script type="text/javascript" src="js/functions.js?ver=<?php echo time(); ?>"></script>
<?php $conn->close(); ?> 
<script src="js/wow.min.js"></script>
<script>
new WOW().init();
</script>
</body>
</html>