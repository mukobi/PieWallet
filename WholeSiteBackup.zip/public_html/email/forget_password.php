<?php
$message = 'Greetings '.$firstname.',

We have requested a password reset for your PayPeer.io account. Please click the link below to reset your password.

http://www.paypeer.io/resetPassword.php?email='.$email.'&t='.$token.' 

If you did not request a password reset, please ignore this email and check that your account is secure.

Sincerely,

PayPeer.io Support Team';
?>