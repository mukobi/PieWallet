<?php
$message = 'Greetings '.$firstname.'

Thank you for signing up for PayPeer.io !

Just one more step before you have access to your account.

Please click the link below to verify your account. After clicking in the link provided you will be redirected to the login page where you can reset your password.

http://www.paypeer.io/verify.php?email='.$email.'&t='.$token.'

Since you are new to PayPeer.io, we recommend that you visit our FAQ page for more information about our platform.

For any other questions or concerns, please contact support by emailing support@paypeer.io.

Sincerely,

PayPeer Team';