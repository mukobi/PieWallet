<?php

namespace Blocktrail\SDK\Connection\Exceptions;

use Blocktrail\SDK\Exceptions\BlocktrailSDKException;

/**
 * Class MissingEndpoint
 *
 */
class MissingEndpoint extends BlocktrailSDKException {

}
