<?php

namespace Blocktrail\SDK\Connection\Exceptions;

use Blocktrail\SDK\Exceptions\BlocktrailSDKException;

/**
 * Class EndpointSpecificError
 *
 */
class EndpointSpecificError extends BlocktrailSDKException {

}
