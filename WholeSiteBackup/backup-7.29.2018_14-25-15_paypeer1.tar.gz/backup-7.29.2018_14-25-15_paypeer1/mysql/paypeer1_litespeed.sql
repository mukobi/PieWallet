-- MySQL dump 10.13  Distrib 5.6.36-82.1, for Linux (x86_64)
--
-- Host: localhost    Database: paypeer1_litespeed
-- ------------------------------------------------------
-- Server version	5.6.36-82.1-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!50112 SELECT COUNT(*) INTO @is_rocksdb_supported FROM INFORMATION_SCHEMA.SESSION_VARIABLES WHERE VARIABLE_NAME='rocksdb_bulk_load' */;
/*!50112 SET @save_old_rocksdb_bulk_load = IF (@is_rocksdb_supported, 'SET @old_rocksdb_bulk_load = @@rocksdb_bulk_load', 'SET @dummy_old_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @save_old_rocksdb_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 SET @enable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = 1', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @enable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;

--
-- Table structure for table `ls_faqs`
--

DROP TABLE IF EXISTS `ls_faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ls_faqs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ls_faqs`
--

LOCK TABLES `ls_faqs` WRITE;
/*!40000 ALTER TABLE `ls_faqs` DISABLE KEYS */;
INSERT INTO `ls_faqs` (`id`, `title`, `description`, `created`) VALUES (1,'-Are there any extra fees when using Shapeshift integration?','<p>No! PayPeer does not charge any added fees when using our ShapeShift integration when exchanging one asset for another. Transactions are done directly by Shapeshift and users should be fimiliar with their terms, conditions, and policies.<br />\r\n&nbsp;</p>\r\n','2018-03-20 10:01:43'),(2,' -How do I contact Support?','<p>You can contact Support by clikcing the &quot;Info&quot; tab on the side menu and clicking the &quot;Support&quot; link.</p>\r\n','2018-03-20 10:00:52'),(5,'-Can I delete my PayPeer account?','<p>Yes, you can delete your account visiting your &quot;Account&quot; page and clicking the tab labeled &quot;Delete Account&quot;. You will be asedkf or your password.</p>\r\n\r\n<p><strong><em>WARNING:</em> </strong>Unless you have written down or secured your Private keys to your account before deleting your account, your funds will be lost.<br />\r\n&nbsp;</p>\r\n','2018-03-20 10:00:18'),(6,'-Can I obtain my Private keys? Where do I find my Private Key information?','<p>Yes, To obtian your private keys, go to your &quot;Account&quot; page and click the box that says &quot;get keys&quot;. Your private Keys for both Bitcoin (BTC) and Litecoin (LTC) will be displayed. These keys must be kept secret, unless you want your funds to fall into the wrong hands. Please make sure you do not perfrom this action around others, as private keys are essential to your wallet&#39;s security.<br />\r\n&nbsp;</p>\r\n','2018-03-20 09:59:01'),(7,'-Can PayPeer wallets receive funds from non PayPeer users?','<p>Yes. Users of other 3rd party wallets can send you coins by scanning the QR code on your profile. You can set your account to private if you do not want&nbsp;<br />\r\nyour profile to be found by others.<br />\r\n&nbsp;</p>\r\n','2018-03-20 09:57:47'),(8,'-Can other users see my public keys? ','<p>No. Part of Our design process was to allow users to send to other users without having to imput a long and complicated&nbsp;public key. However, users can use third party wallets and applications to scan your recieving QR code to obtain your public keys.</p>\r\n','2018-03-20 09:57:59'),(9,'-Are there any fees for sending to another user?','<p>No, we do not charge a fee for user to user transactions.</p>\r\n','2018-03-20 09:55:08'),(10,'-What Crypto Assets does PayPeer offer?','<p><br />\r\nBitcoin (BTC) and Litecoin (LTC). We plan to offer ETH in 2018.</p>\r\n','2018-03-20 09:54:21'),(11,'-What Is PayPeer?','<p><br />\r\nPayPeer is a platform that allows users to Buy, Sell, Send, and Exchange cryptocurrencies like&nbsp;<br />\r\nBitcoin and Litecoin all on one, easy to use platform. Buy Cryptocurrencies through Coinbase, Send Bitcoin and Litecoin to freinds you follow or other users by simply searching there username,<br />\r\nand exchange your crypto for other coins through our integrated ShapeShift.</p>\r\n','2018-03-20 09:53:49'),(22,'-What do I do If forgot my password to my PayPeer account?','<p>You can recover your account via email at anytime in the instance where you lose or forget your password. If you lose acecss to your account, and are unable to recover your account through traditional methods, you may lose access to your account. However, If you have access to your priavte keys, and you are locked out of your account, you can simply export your funds to a new wallet.<br />\r\n&nbsp;</p>\r\n','2018-03-20 10:02:29'),(23,'-What KYC/AML is obtained by PayPeer?','<p>- PayPeer does not collect SSN or other Peronsal identification such as Buisness inforamtion, Utility bills, or Bank statements. During the&nbsp;sign up process you are asked to chose a nickname, a strong password, and go through the&nbsp;email verification process.<br />\r\n&nbsp;</p>\r\n','2018-03-21 18:58:35'),(24,'  -Can I use PayPeer Privately?','<p>Yes, your PayPeer account can operate privately. PayPeer has a social networking like system that allows users to search for other users on our platform and send them various crypto assets in seconds. However,<br />\r\nyou can still make your account private if you don&#39;t want other users to find you in our search directory. You can switch this on and off as you please.</p>\r\n\r\n<p><br />\r\n&nbsp;</p>\r\n','2018-03-20 10:04:37'),(25,'-How do I make my account private?','<p>Simply travel to your &quot;Account&quot; page and click the tab that says &quot;Privacy settings&quot; and change if your profile can be searched and followed.<br />\r\n&nbsp;</p>\r\n','2018-03-20 10:05:12'),(26,'-I am getting a \"Dust amount detected in one output\" error message. What does this mean?','<p>If you are getting a red error&nbsp;message that reads,&nbsp;&quot;Dust ammount detected in one output- for more infomation...&quot; when trying to send Bitcoin or Litecoin to another user, this means that you are trying to send an output that cost more than 1/3 the output in fees. <strong>In other words, your transaction is too small.</strong> If<strong> </strong><em>dust transaction&nbsp;errors</em> did not occur, one user can spam the Bitcoin and Litecoin networks with thousands of transactions, which would clog the netowrk. If you get this message, try sending a larger ammount of Bitcoin or Litecoin. If the issue continues even after sending large ammounts, email support@paypeer.io for assistance.</p>\r\n','2018-03-21 12:35:58'),(27,'-How do I contact Support?','<p>Email: support@paypeer.io</p>\r\n','2018-03-23 11:27:08');
/*!40000 ALTER TABLE `ls_faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ls_followers`
--

DROP TABLE IF EXISTS `ls_followers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ls_followers` (
  `followID` bigint(11) NOT NULL AUTO_INCREMENT,
  `followBy` bigint(11) NOT NULL,
  `followTo` bigint(11) NOT NULL,
  `followDate` datetime NOT NULL,
  PRIMARY KEY (`followID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ls_followers`
--

LOCK TABLES `ls_followers` WRITE;
/*!40000 ALTER TABLE `ls_followers` DISABLE KEYS */;
INSERT INTO `ls_followers` (`followID`, `followBy`, `followTo`, `followDate`) VALUES (1,3,1,'2018-03-18 07:47:55'),(2,1,3,'2018-03-18 07:49:45'),(4,1,24,'2018-03-22 01:57:37'),(5,24,1,'2018-03-26 19:08:06'),(6,1,25,'2018-03-28 23:24:23'),(7,31,1,'2018-04-12 23:01:25'),(8,1,31,'2018-04-12 23:01:33');
/*!40000 ALTER TABLE `ls_followers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ls_transactions`
--

DROP TABLE IF EXISTS `ls_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ls_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL COMMENT '1=> Bitcoin, 2=> Litecoin',
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `amount` varchar(200) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ls_transactions`
--

LOCK TABLES `ls_transactions` WRITE;
/*!40000 ALTER TABLE `ls_transactions` DISABLE KEYS */;
INSERT INTO `ls_transactions` (`id`, `type`, `sender_id`, `receiver_id`, `amount`, `transaction_id`, `created`) VALUES (1,2,1,3,'100000','391581fa2c721d83b5cd473c4a0fdf0a8ea25916328af0dea5b5a7b9a26bb40b','2018-03-19 07:00:36'),(2,2,24,1,'100000','ff8e0e75704be15692beda096549902e4a9b0d68d921194707288e1a8c67d87d','2018-03-24 01:38:24'),(3,2,1,24,'100000','586f7fb90ec98d236983a842a5f54e7ade3af0cf8cae0ffc7b15bec16459eae7','2018-03-24 02:23:23'),(4,2,1,24,'100000','f2a2157c2b56cb586ccd54dd4308f6c824323bbd2de9e7ce827c2fb17f0c65a4','2018-03-24 14:17:55'),(5,2,1,24,'100000','37fddb70da03955ae596131c2491e4030beb1d84d3de0df145c8910eac7f328c','2018-03-26 00:12:19'),(6,2,1,24,'100000','3841f4c0fc0f84209aeb9e02e669629757386617be17c0a9b86bee13d1db95ee','2018-03-28 01:27:45'),(7,2,1,25,'3000000','c6318110bab8bab6c924403f3c6814a6d78d6e7cd413316bf3a3355b506a7e8e','2018-03-28 23:24:33'),(8,2,24,1,'100000','f6882fd734861f61f3f7a809d972be5ae7eb75de45ab89eb00fc88b33743e611','2018-04-02 21:18:53'),(9,2,1,31,'100000','bf2c5e235bf98eebc31f67d88ca3ed67722faefe87a49e3bcd3e72f559b8712e','2018-04-12 23:06:08');
/*!40000 ALTER TABLE `ls_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ls_users`
--

DROP TABLE IF EXISTS `ls_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ls_users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `nickname` varchar(25) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `bitcoin_private_key` varchar(500) DEFAULT NULL,
  `bitcoin_address` varchar(500) DEFAULT NULL,
  `litecoin_private_key` varchar(500) DEFAULT NULL,
  `litecoin_address` varchar(500) DEFAULT NULL,
  `label` varchar(20) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `labelBTC` varchar(20) NOT NULL,
  `addressBTC` varchar(255) NOT NULL,
  `user_img` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(10) NOT NULL,
  `hide_profile` int(2) NOT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `account_verify_token` varchar(100) DEFAULT NULL,
  `litecoin_QR` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ls_users`
--

LOCK TABLES `ls_users` WRITE;
/*!40000 ALTER TABLE `ls_users` DISABLE KEYS */;
INSERT INTO `ls_users` (`id`, `firstname`, `lastname`, `nickname`, `email`, `password`, `bitcoin_private_key`, `bitcoin_address`, `litecoin_private_key`, `litecoin_address`, `label`, `address`, `labelBTC`, `addressBTC`, `user_img`, `created_at`, `status`, `hide_profile`, `remember_token`, `password_reset_token`, `account_verify_token`, `litecoin_QR`) VALUES (1,'Ethan','C','Ethan','chiassonethan@gmail.com','$2y$10$4tooNZ6L992nDi/SEiRzb.Sg22CWhwaUEvFgDnGE/F6I9TIwYB3L2','8241956d7997ac86a1bef4ea28cc0854905c0cf9a7f2ab9dc82efa7baf360500','1LJGGiqnTP1ALqTwdYxQPEN1GcXk7v6eWk','b7551d84c16f7a71b9d47c22f6371a24230e1deed70dd46df4c4f52cecbc70b4','LWuBmt1QMhrnp97w8vyMXPG4kPQ4CAW2Kn',NULL,'','','','profile picture20180316053854.PNG','2018-03-16 05:37:40','active',0,NULL,NULL,NULL,''),(24,'David','Park','Heejoon','hjdavidpark@gmail.com','$2y$10$on6a8zkRiJ4OMzWwiO.i0e3QuYPqEyQfKvb.MAm95XDCVzTFxjxdS','37bfef93a501837db5f69bd4ec4cb86a5dd3f8329f7e926085914ce57008b620','18QkMCjiMUzfbU6uaQ1gqv6kYdCTLm6CxY','dfa9983ea03a763809b0ac483a40c05b091963ee50f87774920fbb8a76df71e8','Le9aWjDbpEwusszhzRGqpDt4gkCo5PaHzc',NULL,'','','','demo_user.jpg','2018-03-22 00:34:38','active',0,NULL,NULL,NULL,''),(25,'michael','gu','boxmining','contact@boxmining.com','$2y$10$57AMvCGNNESDX7pvscUAtOp2Ju3REA5r5FcKlKBruJeUG3VH7BxX2','c0fde248cb6234bdca4066dc09da61dd1212a0b38add1bf896b212e6b9f598f8','1mVwcdRcH6CsE3UfjTRuFRP3E9j6kLw2J','7247b1af94d0c4c7e67960cb0001959f3aa63b285d527e8f0fd53fff4226df1c','LSaNpMi7FFjsK6XMdtVkrWnHee7h1Dv7zH',NULL,'','','','demo_user.jpg','2018-03-23 11:09:14','inactive',0,NULL,NULL,'ZneCRRYdYpWMJk2NFJUDegRGcVHUi1KhoZTfQSsOioA1JDPonK',''),(26,'John','Doe','JohnDoe','ethanls@protonmail.com','$2y$10$RYgf5H4Ht9ys6FsoWM2wzuwzywTBs2qejAZKYotVzIMKXbOA/Nas2','4c2255b6d96675d752908f2fe2b47cd7d98cb145bed3ca18738650c5f543dc45','1HbDP2GtUvwhVRcMJHDJNP7FbwJr63Wg4L','859ac91cd862c9adc5a343eee41a244d6a8ba5764b017f9ca16e4aef070f7ae2','LhPTMJ2nfDVgb4hdXYj2GFyVH6Czkbypfh',NULL,'','','','images20180328134400.png','2018-03-27 10:30:09','active',0,NULL,NULL,NULL,''),(27,'Testing','Testing','Testing','testing_testing@mailinator.com','$2y$10$wC6Kdt6V/7DuZgflMjEh.O98mGOV5X6nqqTSWeT5V8oCrE2h938Sm','1aaf46ad8b0c48a744100b2d292ea8e445e8d31e39e3c99913c00a4157cd71f8','1GExS8UQrhZCV6FafThopme7cZLTtwjh6M','c7e0878e9410d73e78799ae576ffdf1678e2b5d909146acf0f8ea10ae829102c','LUuh5qPkpxV9pLV419iwJnA5VHRusAcwdD',NULL,'','','','user20180327230720.png','2018-03-27 22:59:57','active',0,NULL,NULL,NULL,''),(29,'wai','see','wai','farm2coin@protonmail.com','$2y$10$djcQLNeK69y.J6G/Hy63RufxFXtUYKjvPAHZciOzcLwH1940HBVB6','924bcfb6913aa1d67ba18c64613bd9d2115c25c47416089035f61049cfeeb3c4','1Ag29cNmWuCpK6BGKQwBtrtMJcyeEjACcu','5110207b933f31244926e193bf605563f542d7f5a4b88ce54ac9ebfe0f321e8c','LWLTrMSpmjQmuCSZ1XJxvr9831kRQUpkZa',NULL,'','','','demo_user.jpg','2018-03-28 20:52:26','inactive',0,NULL,NULL,'DTPbkKbQHSqwXx5RfyIUwHs0h2vxYf2C8RNtBYjjQJPOgUFwso',''),(30,'Louie','Procopio','LouiePro','Crypt0coin@null.net','$2y$10$wP/PABSZrcK2tAdq5vJA8uST2TdbekZbYHjx2rAwnuI/1G40/z.Me','20401f3dc51000891699c72efb0f2b459859095b243757680081be550a39eabe','19MdVYJmpRdhPrg4zWL5G9b9BW7ywzoqKj','bc99c4aa6599b350a51c01bbc040d70f34c60a34d6acb20a46447e53e305f6c4','LhKX4BXuaH8vzoqUfm6deGaQcFQHTUKiRV',NULL,'','','','demo_user.jpg','2018-04-06 17:47:14','active',0,NULL,NULL,NULL,''),(31,'Wai','See','Yash','ychoukhan@gmail.com','$2y$10$5kPH8FlNxZXgPnRdwWURF.c9a4dJgnMa.hiO7JW15rY5NsjZhpcsK','b460e181c5ebfcc3436dc4ea98b5348a346cf86e2170cc417b53e6cfd84c8cd3','1Fz3MUwdp9eKnYGXZeNrnT3o8uyd19KfSU','b50a6102587bf5522267b18a5cf5a89f81483cd006773dd0b6d2c012ebaba214','LeSDP6WPdg6eQa1w8vsKX2D8inxAWUXWt1',NULL,'','','','demo_user.jpg','2018-04-12 22:58:35','active',0,NULL,NULL,NULL,''),(32,'David','Koolhoven','djk','david@koolhovensystems.com','$2y$10$/pMsReZBmdpNenGQWyv8BOdr6CJoLjEW/rCsMTNZwlhjGWlawn8yu','30ff5f31cfd0db4e0b4563f4cc8bcdfcbd4c3d427b5eb2dbe930f28643b4ea67','1QESMfxoXQy7TAj4SodRJ6mSxNivQVGZCb','406c0c4c06c6a4330cddbb1d3f3e4ef8d10560ec48ce53fd895f94374b06d755','La9xJM2tGBg6RXuL4MVSQ4jRhYDF7aYatv',NULL,'','','','demo_user.jpg','2018-04-19 10:48:22','inactive',0,NULL,NULL,'SCfjOVxMIqXp41A1HY38am6r7XSLRvGK8W3WRBIA1G05IB7pzb',''),(33,'Pavel','Panayotov','pafko1','pafko1@gmail.com','$2y$10$KcknmLuQRYQaTBBhP4NwTusi8qru9wA/Yp1X64BdpwNR25Afrfexe','bf79036fc8cfe857fe35052e29d797f34018d5a8d1f1c0ee9f88360637ddb442','1HJTzSciFpQi1Nem3CgzC8oTVWCRGUqF4g','e8218e1331e0c28df17ec9195a7f5046da31af00cff56b3429469ed7ce79924b','LYWPVYJrPXMCYeBUp6z88fnHZKZyWU72ba',NULL,'','','','demo_user.jpg','2018-05-01 16:05:53','active',0,NULL,NULL,NULL,'');
/*!40000 ALTER TABLE `ls_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'paypeer1_litespeed'
--

--
-- Dumping routines for database 'paypeer1_litespeed'
--
/*!50112 SET @disable_bulk_load = IF (@is_rocksdb_supported, 'SET SESSION rocksdb_bulk_load = @old_rocksdb_bulk_load', 'SET @dummy_rocksdb_bulk_load = 0') */;
/*!50112 PREPARE s FROM @disable_bulk_load */;
/*!50112 EXECUTE s */;
/*!50112 DEALLOCATE PREPARE s */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-29 14:25:15
