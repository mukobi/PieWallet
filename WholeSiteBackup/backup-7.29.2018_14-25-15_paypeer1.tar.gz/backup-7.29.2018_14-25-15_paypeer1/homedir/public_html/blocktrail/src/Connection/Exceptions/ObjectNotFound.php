<?php

namespace Blocktrail\SDK\Connection\Exceptions;

use Blocktrail\SDK\Exceptions\BlocktrailSDKException;

/**
 * Class ObjectNotFound
 *
 */
class ObjectNotFound extends BlocktrailSDKException {

}
