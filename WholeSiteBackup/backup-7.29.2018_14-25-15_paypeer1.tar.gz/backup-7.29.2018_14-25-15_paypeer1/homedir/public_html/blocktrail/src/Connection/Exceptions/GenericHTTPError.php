<?php

namespace Blocktrail\SDK\Connection\Exceptions;

use Blocktrail\SDK\Exceptions\BlocktrailSDKException;

/**
 * Class GenericHTTPError
 *
 */
class GenericHTTPError extends BlocktrailSDKException {

}
