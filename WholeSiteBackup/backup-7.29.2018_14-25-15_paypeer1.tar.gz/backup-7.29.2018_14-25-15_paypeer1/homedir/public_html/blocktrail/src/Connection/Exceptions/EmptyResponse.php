<?php

namespace Blocktrail\SDK\Connection\Exceptions;

use Blocktrail\SDK\Exceptions\BlocktrailSDKException;

/**
 * Class EmptyResponse
 *
 */
class EmptyResponse extends BlocktrailSDKException {

}
