<?php

namespace Blocktrail\SDK\Exceptions;

class WalletDecryptException extends BlocktrailSDKException {

}
